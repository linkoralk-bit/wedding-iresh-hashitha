import {
  Component,
  OnInit,
  OnDestroy,
  AfterViewInit,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  NgZone,
  ViewChild,
  ElementRef,
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import {
  DomSanitizer,
  SafeResourceUrl,
} from '@angular/platform-browser';
import { ApiService } from '../../services/api.service';


interface Petal {
  id: number;
  x: number;
  size: number;
  delay: number;
  duration: number;
  colorIdx: number;
  opacity: number;
}

interface ScheduleItem {
  time: string;
  label: string;
}

interface WeddingEvent {
  key: 'church' | 'poruwa' | 'homecoming';
  palette: 'sage' | 'ivory' | 'wine';
  eyebrow: string;
  title: string;
  subtitle: string;
  date: string;
  dateLabel: string;
  dayName: string;
  time: string;
  venue: string;
  address: string;
  mapQuery: string;
  notes?: string;
  image: string;
  schedule: ScheduleItem[];
}

interface StoryChapter {
  chapter: string;
  title: string;
  description: string;
  image: string;
}

interface Countdown {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface RsvpForm {
  name: string;
  phone: string;
  guests: number;
  attending: 'yes' | 'no';
  note: string;
}


@Component({
  selector: 'app-event',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventComponent
  implements OnInit, OnDestroy, AfterViewInit
{
  @ViewChild('bgMusic')
  bgMusicRef?: ElementRef<HTMLAudioElement>;
  mapEmbeds: Record<string, SafeResourceUrl> = {};
  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private cdr: ChangeDetectorRef,
    private zone: NgZone,
    private sanitizer: DomSanitizer
  ) {}

  // ─────────────────────────────────────────────────────────
  // INTRO OVERLAY (Envelope-tap to open)
  // ─────────────────────────────────────────────────────────
  introOpen = true;        // overlay mounted?
  introClosing = false;    // fade-out phase
  introTapped = false;     // envelope opened?

  // ─────────────────────────────────────────────────────────
  // EVENT DATA
  // ─────────────────────────────────────────────────────────

  event: any = null;

  groomName = '';
  brideName = '';

  groomParents = '';
  brideParents = '';

  storyChapters: StoryChapter[] = [];
  galleryImages: string[] = [];

  readonly heroDates = '22 · 23 · 24 July 2026';
  readonly heroSubtitle = 'A three-day celebration · Sri Lanka';

  readonly heroImage = '/assets/images/hero.jpg';

  // ─────────────────────────────────────────────────────────
  // EVENTS (HARDCODED)
  // ─────────────────────────────────────────────────────────

  readonly weddingEvents: WeddingEvent[] = [
    {
      key: 'church',
      palette: 'sage',
      eyebrow: 'Day One · The Sacred Vow',
      title: 'Church Function',
      subtitle: 'A blessing under sacred arches',
      date: '2026-07-22',
      dateLabel: '22 July 2026',
      dayName: 'Wednesday',
      time: '11:30 AM onwards',
      venue: "St. Joseph's Church",
      address: 'Wennappuwa, Sri Lanka',
      mapQuery: "St. Joseph's Church, Wennappuwa, Sri Lanka",
      notes: 'A sacred ceremony of devotion, followed by light refreshments.',
      image: 'assets/images/church.jpg',
      schedule: [
        { time: '11:00 AM', label: 'Guest Arrival' },
        { time: '11:30 AM', label: 'Holy Matrimony Begins' },
        { time: '12:30 PM', label: 'Blessings & Photographs' },
        { time: '01:00 PM', label: 'Snack Time & Fellowship' },
      ],
    },
    {
      key: 'poruwa',
      palette: 'ivory',
      eyebrow: 'Day Two · The Golden Celebration',
      title: 'Poruwa Ceremony & Reception',
      subtitle: 'A timeless tradition in pearl and champagne',
      date: '2026-07-23',
      dateLabel: '23 July 2026',
      dayName: 'Thursday',
      time: 'Poruwa 4:30 PM · Reception 7:00 PM',
      venue: 'Monarch Imperial',
      address: '31A New Hospital Rd, Sri Jayawardenepura',
      mapQuery: 'Monarch Imperial, Sri Lanka',
      notes: 'An evening of vows, dinner, and dancing beneath chandeliers.',
      image: 'assets/images/poruwa.jpg',
      schedule: [
        { time: '04:30 PM', label: 'Poruwa Ceremony' },
        { time: '06:00 PM', label: 'Cocktails & Canapés' },
        { time: '07:00 PM', label: 'Reception Begins' },
        { time: '12:00 AM', label: 'After-Party' },
      ],
    },
    {
      key: 'homecoming',
      palette: 'wine',
      eyebrow: 'Day Three · The Velvet Night',
      title: 'Homecoming',
      subtitle: 'An intimate evening in oxblood and gold',
      date: '2026-07-24',
      dateLabel: '24 July 2026',
      dayName: 'Friday',
      time: '6:00 PM onwards',
      venue: 'Maze Glass House',
      address: ' Chilaw - Colombo Main Rd, Wennappuwa 61170',
      mapQuery: 'Maze Glass House, Wennappuwa',
      notes: 'A warm welcome home — candlelight, wine, and laughter.',
      image: 'assets/images/homecoming.jpg',
      schedule: [
        { time: '06:00 PM', label: 'Welcome & Drinks' },
        { time: '07:00 PM', label: 'Dinner is Served' },
        { time: '08:30 PM', label: 'Toasts & Music' },
        { time: '12:00 AM', label: 'Farewell' },
      ],
    },
  ];

  private preloadMapEmbeds(): void {
    this.weddingEvents.forEach((e) => {
      this.mapEmbeds[e.key] =
        this.sanitizer.bypassSecurityTrustResourceUrl(
          `https://maps.google.com/maps?q=${encodeURIComponent(
            e.mapQuery
          )}&output=embed`
        );
    });
  }

  // ─────────────────────────────────────────────────────────
  // DEFAULT STORY / GALLERY
  // ─────────────────────────────────────────────────────────

  readonly defaultStory: StoryChapter[] = [
    {
      chapter: 'Chapter I',
      title: 'How We Met',
      description:
        'A quiet evening, an unexpected smile — the moment two stories quietly began to share a single page.',
      image: '/assets/images/story-1.jpg',
    },
    {
      chapter: 'Chapter II',
      title: 'Becoming Us',
      description:
        'Through cities and seasons, through laughter and long conversations, we built a small world that felt like home.',
      image: '/assets/images/story-2.jpg',
    },
    {
      chapter: 'Chapter III',
      title: 'The Promise',
      description:
        'Beneath a sky on fire, a question was asked, an answer was given — and forever found its name.',
      image: '/assets/images/story-3.jpg',
    },
  ];

  readonly defaultGallery: string[] = [
    '/assets/images/story-1.jpg',
    '/assets/images/story-2.jpg',
  ];

  // ─────────────────────────────────────────────────────────
  // GETTERS
  // ─────────────────────────────────────────────────────────

  get story(): StoryChapter[] {
    return this.storyChapters || [];
  }

  get gallery(): string[] {
    if (this.galleryImages && this.galleryImages.length > 0) {
      return this.galleryImages;
    }
    return this.defaultGallery;
  }

  get coupleFirst(): string {
    return this.brideName || 'Hirushi';
  }

  get coupleSecond(): string {
    return this.groomName || 'Vishwa';
  }

  // ─────────────────────────────────────────────────────────
  // FLOATING HEARTS
  // ─────────────────────────────────────────────────────────

  hearts: Petal[] = [];

  private readonly petalColors = [
    '#c89a52',   // champagne
    '#8aa080',   // sage
    '#5c1a26',   // wine
    '#a85b6a',   // soft rose
  ];

  // ─────────────────────────────────────────────────────────
  // MUSIC
  // ─────────────────────────────────────────────────────────

  isPlaying = false;

  // ─────────────────────────────────────────────────────────
  // COUNTDOWN
  // ─────────────────────────────────────────────────────────

  readonly targetDate = new Date('2026-07-22T11:30:00+05:30').getTime();

  countdown: Countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };

  private countdownTimer?: number;

  // ─────────────────────────────────────────────────────────
  // RSVP
  // ─────────────────────────────────────────────────────────

  rsvp: RsvpForm = {
    name: '',
    phone: '',
    guests: 1,
    attending: 'yes',
    note: '',
  };

  rsvpSubmitted = false;
  guestOptions = [1, 2, 3, 4, 5];

  // ─────────────────────────────────────────────────────────
  // LIFECYCLE
  // ─────────────────────────────────────────────────────────

  ngOnInit(): void {
    this.generateHearts(18);
    this.updateCountdown();
    this.preloadMapEmbeds();
    this.loadEvent();

    this.zone.runOutsideAngular(() => {
      this.countdownTimer = window.setInterval(() => {
        this.updateCountdown();
        this.zone.run(() => this.cdr.markForCheck());
      }, 1000);
    });
  }

  ngAfterViewInit(): void {}

  ngOnDestroy(): void {
    if (this.countdownTimer) clearInterval(this.countdownTimer);
    const a = this.bgMusicRef?.nativeElement;
    if (a) a.pause();
  }

  // ─────────────────────────────────────────────────────────
  // OPEN INVITATION (envelope tap)
  // ─────────────────────────────────────────────────────────

  openInvitation(): void {
    if (this.introTapped) return;   // prevent double-tap restart
    this.introTapped = true;

    // 1. Start music immediately (inside user gesture)
    this.startMusic();

    // 2. Envelope opens for ~1.9s (flap 0.7s + letter slide 1.2s with delay)
    setTimeout(() => {
      this.introClosing = true;
      this.cdr.markForCheck();
    }, 1900);

    // 3. Remove overlay after fade-out (1900 + 600)
    setTimeout(() => {
      this.introOpen = false;
      this.cdr.markForCheck();
    }, 2500);

    this.cdr.markForCheck();
  }

  private startMusic(): void {
    const a = this.bgMusicRef?.nativeElement;
    if (!a) return;
    a.volume = 0.35;
    a.play()
      .then(() => {
        this.isPlaying = true;
        this.cdr.markForCheck();
      })
      .catch((err) => {
        console.warn('Autoplay blocked:', err);
      });
  }

  // ─────────────────────────────────────────────────────────
  // LOAD EVENT
  // ─────────────────────────────────────────────────────────

  private loadEvent(): void {
    const slug = this.route.snapshot.paramMap.get('slug');

    this.api.getEvent(slug!).subscribe({
      next: (res: any) => {
        this.event = res;
        this.groomName = res?.groom || '';
        this.brideName = res?.bride || '';
        this.groomParents = res?.parents?.groom || '';
        this.brideParents = res?.parents?.bride || '';

        this.storyChapters = [];
        if (Array.isArray(res?.story)) {
          this.storyChapters = res.story.map((s: any, index: number) => ({
            chapter: s.chapter || `Chapter ${index + 1}`,
            title: s.title || s.heading || s.name || '',
            description:
              s.description || s.body || s.story || s.content || '',
            image: s.image || s.imageUrl || s.photo || s.img || '',
          }));
        }

        if (res?.gallery?.length) {
          this.galleryImages = res.gallery;
        }

        this.cdr.markForCheck();
      },
      error: (err) => console.error('Error loading event:', err),
    });
  }

  // ─────────────────────────────────────────────────────────
  // HEARTS
  // ─────────────────────────────────────────────────────────

  private generateHearts(count: number): void {
    this.hearts = Array.from({ length: count }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: 12 + Math.random() * 16,
      delay: -Math.random() * 30,
      duration: 16 + Math.random() * 18,
      colorIdx: i % this.petalColors.length,
      opacity: 0.35 + Math.random() * 0.4,
    }));
  }

  trackHeart = (_: number, p: Petal) => p.id;

  heartColor(idx: number): string {
    return this.petalColors[idx] ?? this.petalColors[0];
  }

  // ─────────────────────────────────────────────────────────
  // MUSIC TOGGLE
  // ─────────────────────────────────────────────────────────

  toggleMusic(audio?: HTMLAudioElement): void {
    const a = audio ?? this.bgMusicRef?.nativeElement;
    if (!a) return;

    if (this.isPlaying) {
      a.pause();
      this.isPlaying = false;
    } else {
      a.volume = 0.80;
      a.play()
        .then(() => {
          this.isPlaying = true;
          this.cdr.markForCheck();
        })
        .catch((err) => console.error(err));
    }
    this.cdr.markForCheck();
  }

  // ─────────────────────────────────────────────────────────
  // COUNTDOWN
  // ─────────────────────────────────────────────────────────

  private updateCountdown(): void {
    const now = Date.now();
    const distance = this.targetDate - now;

    if (distance <= 0) {
      this.countdown = { days: 0, hours: 0, minutes: 0, seconds: 0 };
      return;
    }

    this.countdown = {
      days: Math.floor(distance / (1000 * 60 * 60 * 24)),
      hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
      minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
      seconds: Math.floor((distance % (1000 * 60)) / 1000),
    };
  }

  pad(v: number): string {
    return String(v).padStart(2, '0');
  }

  // ─────────────────────────────────────────────────────────
  // SCROLL
  // ─────────────────────────────────────────────────────────

  scrollTo(id: string): void {
    const el = document.getElementById(id);
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ─────────────────────────────────────────────────────────
  // GALLERY
  // ─────────────────────────────────────────────────────────

  galleryClass(index: number): string {
    if (index === 0) return 'g-feature';
    if (index === 3) return 'g-wide';
    return '';
  }

  // ─────────────────────────────────────────────────────────
  // MAPS
  // ─────────────────────────────────────────────────────────

  mapLink(query: string): string {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      query
    )}`;
  }

  // ─────────────────────────────────────────────────────────
  // RSVP
  // ─────────────────────────────────────────────────────────

  submitRsvp(): void {
    const payload = {
      eventId: this.event?._id,
      name: this.rsvp.name,
      phone: this.rsvp.phone,
      guestCount: this.rsvp.guests,
      attending: this.rsvp.attending === 'yes',
      note: this.rsvp.note,
    };

    this.api.submitRSVP(payload).subscribe({
      next: () => {
        this.rsvpSubmitted = true;
        this.cdr.markForCheck();
      },
      error: (err) => console.error('RSVP submission failed:', err),
    });
  }
}
